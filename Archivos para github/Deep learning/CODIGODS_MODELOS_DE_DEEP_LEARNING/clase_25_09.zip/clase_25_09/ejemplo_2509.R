# OJO- antes instalé la versión más actual de tensorflow en conda.
# Si tengo fallas, debo instalar tensorflow 2.10
install.packages("keras3")

keras3::install_keras(backend = "tensorflow",
                      envname = "ambiente2",
                      python_version = "3.9.23")

# EJEMPLO DE LA CLASE

#Para sobreescribir códigos: 
install.packages("keras")

#Inicio ejemplo
library(keras3)
library(keras)
mnist <- dataset_mnist()
x_train <- mnist$train$x
y_train <- mnist$train$y
x_test <- mnist$test$x
y_test <- mnist$test$y


#VISUALIZAMOS UN DATO
#mnist$train$x[1,1:28,1:28]

# Visualizar los datos como imagenes
par(mfcol=c(4,4))
par(mar=c(0, 0, 3, 0), xaxs='i', yaxs='i')
for (i in 1:16) { 
  im <- x_train[i,,]
  im <- t(apply(im, 2, rev)) 
  image(1:28, 1:28, im, col=gray(1-(0:255)/255),
        xaxt='n', main=paste(y_train[i]))
}


#x_train[1,1:28,1:28]

# PREPROCESAMIENTO DE DATOS

# Transformación de los arreglos (reshape)
x_train <- array_reshape(x_train, c(nrow(x_train), 784))
x_test <- array_reshape(x_test, c(nrow(x_test), 784))
# Escalamiento de los datos (rescale)
x_train <- x_train / 255
x_test <- x_test / 255

# TO_CATEGORICAL manda los datos de entrenamiento y test a vecotres
y_train <- to_categorical(y_train, 10)
y_test <- to_categorical(y_test, 10)

# COMO SON LAS NEURONAS

# al
model <- keras_model_sequential() 
model %>% 
  layer_dense(units = 256, activation = 'relu', input_shape = c(784)) %>% 
  layer_dropout(rate = 0.4) %>% 
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dropout(rate = 0.3) %>%
  layer_dense(units = 10, activation = 'softmax')


# layer_dropout --> regularización: en cada capa aaga un porcentaje
# de las neuronas.


# VISAULIZACIÓN DEL MODELO
summary(model)

# VER LA PROXIMA CLASE
devtools::install_github("andrie/deepviz")

library(deepviz)
library(magrittr)
model %>% plot_model()
# VER LA PROXIMA CLASE




# COMPILAR MODELO
model %>% compile(
  loss = 'categorical_crossentropy',
  optimizer = optimizer_rmsprop(),
  metrics = c('accuracy')
)


# ENTRENAMIENTO Y EVALUACION DEL MODELO
history <- model %>% fit(
  x_train, y_train, 
  epochs = 30, batch_size = 128, 
  validation_split = 0.2
)
# epochs: épocas o capas de la red neuronal
# batches: tamaño de lotes (batch_size), define el numero de muestras sobre las
#que se calculará el gradiente y se actualizará el meodelo
# validation_split: partiicón para validación interna; se reserva un porcentaje
#de los datos para validar el rendimiento del modelo (en este momento: 20%)
# EJEMPLO: AL CALCULAR LAS 30 EPOCAS CON 128 MUESTRAS PARA EL GRADIENTE, SE TIENE
# QUE EL NÚMERO 375 SE CALCULA CON: 60000*0.8/128, DONDE 60000 ES EL TAMAÑO DE LA ENTRADA




# DESEMPEÑO DEL ENTRENAMIENTO
plot(history)

# Desempeño datos de prueba
model %>% evaluate(x_test, y_test)

# Predicciones datos de prueba
predicciones = model %>% 
  predict(x_test) %>% 
  k_argmax() %>% 
  array_reshape(., dim = c(10000, 1)) %>% 
  as.vector()

predicciones[1:5]

x_test2 <- mnist$test$x
par(mfrow=c(1,5))
par(mar=c(0, 0, 0, 0), xaxs='i', yaxs='i')
for (i in 1:5) { 
  im <- x_test2[i,,]
  im <- t(apply(im, 2, rev)) 
  image(1:28, 1:28, im, col=gray(1-(0:255)/255),
        xaxt='n')
}

# MATRIZ DE CONFUSIÓN
table(Estimado = predicciones,
      Observado = as.vector(k_argmax(y_test)))








