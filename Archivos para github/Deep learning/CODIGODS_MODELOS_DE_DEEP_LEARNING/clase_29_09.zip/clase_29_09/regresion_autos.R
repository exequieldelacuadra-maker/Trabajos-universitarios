# EJEMPLO CLASE 29-09-2025
# regresión
library(tensorflow)
library(keras3)
library(tidyverse)
library(tidymodels)

# Página web de donde sacaremos el dataset
url <- "http://archive.ics.uci.edu/ml/machine-learning-databases/auto-mpg/auto-mpg.data"
# Nombres variables
col_names <- c("mpg","cylinders","displacement","horsepower","weight","acceleration","model_year", "origin","car_name")

raw_dataset = read.table(
  url,
  header = T,
  col.names = col_names,
  na.strings = "?"  # símbolos NA aparecerán como "?"
)

dataset = raw_dataset %>% select(-car_name) #elimina "car_name" del dataset
head(dataset)

# Limpieza de datos
skimr::skim(dataset)
# n_missing ---> números de NA que aparecen
#complete_rate ---> completitud de los datos


# PODEMOS ESCRIBIR LO SIGUIENTE PARA HACER MÁS LIMPIO EL FLUJO DE TRABAJO:
dataset = raw_dataset %>% 
  select(-car_name) %>%
  na.omit(dataset)
skimr::skim(dataset)


# PREPROCESAMIENTO
# Inspección datos:
dataset %>%
  GGally::ggpairs()

# En este dataset, la variable "origin" contiene variables categóricas:
# {1,2,3}.


# Ahora tomamos la variable "mpg" y la explicamos a partir de las otras
#variables.
# librería "RECIPES": tiene un simil con la cocina
library(recipes)
#library(keras)
dataset <- recipe(mpg ~ ., dataset) %>%
  step_num2factor(origin, levels = c("USA", "Europe", "Japan")) %>%
  step_dummy(origin, one_hot = TRUE) %>%
  prep() %>%
  bake(new_data = NULL)
# nuestros ingredientes
# transformamos o preparamos la variable "origin" con USA, EUROPE, JAPAN
# NOS DICE (con 0 o 1) SI DICHO COMPONENTE PERTENECE 

glimpse(dataset)

#gráfico más bonito


# SEPARACIÓN ENTRENAMIENTO Y PRUEBA

#Toma el 80% de los datos como entrenamiento y 20% de prueba
split <- initial_split(dataset, 0.8)
train_dataset <- training(split)
test_dataset <- testing(split)
# split----> dice a qué categoría o conjunto pertenecerá cada dato observado


#Selección variables modelo --> tomamos los datos con correlación más alta
train_dataset %>%
  select(mpg, cylinders, displacement, horsepower, weight) %>%
  GGally::ggpairs()



#ACOMODAR ETIQUETAS DE REGRESORES
# --> Rregresión simple
# Y= Beta*X + Error ------------> Y: mpg, x_1: cylinders, x_2: displacement, x_3: weight


#Indicación de cuáles son las variables regresoras
#y cuales son las variables objetivo
train_features <- train_dataset %>% select(-mpg) #Sacamos la variable mpg
test_features <- test_dataset %>% select(-mpg) #Sacamos la variable mpg

train_labels <- train_dataset %>% select(mpg) # seleccionamos "mpg"
test_labels <- test_dataset %>% select(mpg) # seleccionamos "mpg"





# NORMALIZACIÓN
my_skim <- skimr::skim_with(numeric = skimr::sfl(mean, sd))
train_dataset %>%
  select(where(~is.numeric(.x))) %>%
  pivot_longer(
    cols = everything(), names_to = "variable", values_to = "values") %>%
  group_by(variable) %>%
  summarise(mean = mean(values), sd = sd(values))
# SE HACE UN CAMBIO DE ESCALA


# Capa de normalización
normalizer <- layer_normalization(axis = -1L) # se crea la capa
normalizer %>% adapt(as.matrix(train_features)) # ajustar estado de la capa de la normalización a los datos
print(normalizer$mean) # almacenar media y varianza
















